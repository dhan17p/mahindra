sap.ui.define(
    [
        "sap/ui/core/mvc/Controller"
    ],
    function(BaseController) {
      "use strict";
  
      return BaseController.extend("folderstruc.controller.App", {
        onInit: function() {
        }
      });
    }
  );
  